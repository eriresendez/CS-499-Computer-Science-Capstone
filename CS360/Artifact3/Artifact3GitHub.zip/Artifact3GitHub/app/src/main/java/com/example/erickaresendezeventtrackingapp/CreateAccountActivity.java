package com.example.erickaresendezeventtrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import com.example.erickaresendezeventtrackingapp.viewmodel.UserViewModel;
import com.example.erickaresendezeventtrackingapp.repository.UserRepository;

public class CreateAccountActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private EditText confirmPasswordEditText;
    private Button createAccountButton;
    private UserViewModel userViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        // Initialize ViewModel
        userViewModel = new ViewModelProvider(this).get(UserViewModel.class);

        // Link UI components (make sure these IDs match your XML layout)
        usernameEditText = findViewById(R.id.createUsername);
        passwordEditText = findViewById(R.id.createPassword);
        confirmPasswordEditText = findViewById(R.id.confirmPassword);
        createAccountButton = findViewById(R.id.submitCreateAccount);

        // Set click listener for create account button
        createAccountButton.setOnClickListener(v -> registerUser());
    }

    /**
     * Validates input and registers new user in the database
     */
    private void registerUser() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();
        String confirmPassword = confirmPasswordEditText.getText().toString().trim();

        // Input validation
        if (username.isEmpty()) {
            Toast.makeText(this, "Please enter a username", Toast.LENGTH_SHORT).show();
            usernameEditText.requestFocus();
            return;
        }

        if (username.length() < 3) {
            Toast.makeText(this, "Username must be at least 3 characters", Toast.LENGTH_SHORT).show();
            usernameEditText.requestFocus();
            return;
        }

        if (password.isEmpty()) {
            Toast.makeText(this, "Please enter a password", Toast.LENGTH_SHORT).show();
            passwordEditText.requestFocus();
            return;
        }

        if (password.length() < 6) {
            Toast.makeText(this, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show();
            passwordEditText.requestFocus();
            return;
        }

        if (confirmPassword.isEmpty()) {
            Toast.makeText(this, "Please confirm your password", Toast.LENGTH_SHORT).show();
            confirmPasswordEditText.requestFocus();
            return;
        }

        if (!password.equals(confirmPassword)) {
            Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            confirmPasswordEditText.requestFocus();
            return;
        }

        // Register user using ViewModel
        userViewModel.registerUser(username, password, new UserRepository.RegistrationCallback() {
            @Override
            public void onSuccess(int userId) {
                runOnUiThread(() -> {
                    Toast.makeText(CreateAccountActivity.this,
                            "Account created successfully!",
                            Toast.LENGTH_SHORT).show();

                    // Navigate back to login
                    Intent intent = new Intent(CreateAccountActivity.this, LoginActivity.class);
                    intent.putExtra("new_username", username);
                    startActivity(intent);
                    finish();
                });
            }

            @Override
            public void onError(String error) {
                runOnUiThread(() -> {
                    Toast.makeText(CreateAccountActivity.this,
                            error,
                            Toast.LENGTH_LONG).show();
                });
            }
        });
    }
}