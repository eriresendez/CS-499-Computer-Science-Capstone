package com.example.erickaresendezeventtrackingapp;

import android.Manifest; // manifest import for permissions
import android.content.Intent;
import android.content.pm.PackageManager; // for permission handling
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat; // for requesting permissions
import androidx.core.content.ContextCompat; // for checking permissions
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private NavigationView navigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Set up the toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Set up drawer layout and navigation view
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);

        // Set up the toggle for the navigation drawer
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        // Handle navigation item clicks
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();
                if (itemId == R.id.nav_home) {
                    Intent intent = new Intent(MainActivity.this, DataGridActivity.class);
                    startActivity(intent);
                } else if (itemId == R.id.nav_sms) {
                    // Handle SMS action
                    handleSmsPermission();
                } else if (itemId == R.id.nav_logout) {
                    logout(); // Call logout method
                } else {
                    Toast.makeText(MainActivity.this, "Unknown option", Toast.LENGTH_SHORT).show();
                }
                drawerLayout.closeDrawers(); // Close drawer after selection
                return true; // Return true to indicate item was selected
            }
        });

    }


    // Method to handle SMS permissions and initiate SMS functionality if allowed.
    private void handleSmsPermission() {
        // Check if SMS permission is granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            // If permission not granted, request it
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS}, 1);
        } else {
            // Permission is granted, proceed with SMS functionality
            sendSmsNotification();
        }
    }

    /**
     * Handle the result of the permission request.
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if (requestCode == 1) { // Check if requestCode matches the one for SMS permission
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted
                sendSmsNotification();
            } else {
                // Permission denied, inform the user
                Toast.makeText(this, "SMS Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    /**
     * Method to simulate SMS notification sending after permission is granted.
     */
    private void sendSmsNotification() {
        // Example placeholder for SMS functionality
        Toast.makeText(this, "SMS Notification sent!", Toast.LENGTH_SHORT).show();
        // SMS sending logic can be added here.
    }


    // Method to handle user logout.

    private void logout() {
        // Clear any user session data if applicable
        Toast.makeText(this, R.string.toast_logged_out, Toast.LENGTH_SHORT).show();

        // Redirect to login activity
        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        startActivity(intent);
        finish(); // Close MainActivity to prevent back navigation
    }

    /**
     * Handle back press to close drawer if open.
     */
    @Override
    public void onBackPressed() {
        // Check if drawer is open before exiting activity
        if (drawerLayout.isDrawerOpen(navigationView)) {
            drawerLayout.closeDrawers();
        } else {
            super.onBackPressed();
        }
    }
}
