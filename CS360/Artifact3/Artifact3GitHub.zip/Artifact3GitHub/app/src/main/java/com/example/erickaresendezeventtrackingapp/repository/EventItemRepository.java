package com.example.erickaresendezeventtrackingapp.repository;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.example.erickaresendezeventtrackingapp.database.AppDatabase;
import com.example.erickaresendezeventtrackingapp.database.dao.EventItemDao;
import com.example.erickaresendezeventtrackingapp.database.entity.EventItem;

import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

/**
 * Repository for EventItem operations.
 * Provides abstraction layer between data source and ViewModels.
 * Manages threading for database operations.
 */
public class EventItemRepository {

    private final EventItemDao eventItemDao;
    private final Executor executor;
    private final LiveData<List<EventItem>> allItems;

    public EventItemRepository(Application application) {
        AppDatabase database = AppDatabase.getInstance(application);
        eventItemDao = database.eventItemDao();
        executor = Executors.newSingleThreadExecutor();
        allItems = eventItemDao.getAllItems();
    }

    /**
     * Get all items (LiveData for reactive UI)
     */
    public LiveData<List<EventItem>> getAllItems() {
        return allItems;
    }

    /**
     * Get items for a specific user
     */
    public LiveData<List<EventItem>> getItemsByUser(int userId) {
        return eventItemDao.getItemsByUser(userId);
    }

    /**
     * Get item by ID
     */
    public LiveData<EventItem> getItemById(int itemId) {
        return eventItemDao.getItemById(itemId);
    }

    /**
     * Insert a new item (async)
     */
    public void insertItem(EventItem item, InsertCallback callback) {
        executor.execute(() -> {
            try {
                long itemId = eventItemDao.insertItem(item);
                if (itemId > 0) {
                    callback.onSuccess((int) itemId);
                } else {
                    callback.onError("Failed to insert item");
                }
            } catch (Exception e) {
                callback.onError("Insert failed: " + e.getMessage());
            }
        });
    }

    /**
     * Insert multiple items (bulk operation)
     */
    public void insertItems(List<EventItem> items, BulkInsertCallback callback) {
        executor.execute(() -> {
            try {
                long[] ids = eventItemDao.insertItems(items);
                callback.onSuccess(ids.length);
            } catch (Exception e) {
                callback.onError("Bulk insert failed: " + e.getMessage());
            }
        });
    }

    /**
     * Update an existing item
     */
    public void updateItem(EventItem item, UpdateCallback callback) {
        executor.execute(() -> {
            try {
                int rowsUpdated = eventItemDao.updateItem(item);
                if (rowsUpdated > 0) {
                    callback.onSuccess();
                } else {
                    callback.onError("Item not found");
                }
            } catch (Exception e) {
                callback.onError("Update failed: " + e.getMessage());
            }
        });
    }

    /**
     * Update item quantity by name (backward compatibility)
     */
    public void updateItemQuantity(String itemName, int newQuantity, UpdateCallback callback) {
        executor.execute(() -> {
            try {
                int rowsUpdated = eventItemDao.updateItemQuantity(itemName, newQuantity);
                if (rowsUpdated > 0) {
                    callback.onSuccess();
                } else {
                    callback.onError("Item not found");
                }
            } catch (Exception e) {
                callback.onError("Update failed: " + e.getMessage());
            }
        });
    }

    /**
     * Delete an item
     */
    public void deleteItem(EventItem item, DeleteCallback callback) {
        executor.execute(() -> {
            try {
                int rowsDeleted = eventItemDao.deleteItem(item);
                if (rowsDeleted > 0) {
                    callback.onSuccess();
                } else {
                    callback.onError("Item not found");
                }
            } catch (Exception e) {
                callback.onError("Delete failed: " + e.getMessage());
            }
        });
    }

    /**
     * Delete item by name (backward compatibility)
     */
    public void deleteItemByName(String itemName, DeleteCallback callback) {
        executor.execute(() -> {
            try {
                int rowsDeleted = eventItemDao.deleteItemByName(itemName);
                if (rowsDeleted > 0) {
                    callback.onSuccess();
                } else {
                    callback.onError("Item not found");
                }
            } catch (Exception e) {
                callback.onError("Delete failed: " + e.getMessage());
            }
        });
    }

    /**
     * Delete all items for a user
     */
    public void deleteItemsByUser(int userId, DeleteCallback callback) {
        executor.execute(() -> {
            try {
                int rowsDeleted = eventItemDao.deleteItemsByUser(userId);
                callback.onSuccess();
            } catch (Exception e) {
                callback.onError("Delete failed: " + e.getMessage());
            }
        });
    }

    /**
     * Get item count for a user
     */
    public void getItemCountByUser(int userId, CountCallback callback) {
        executor.execute(() -> {
            int count = eventItemDao.getItemCountByUser(userId);
            callback.onResult(count);
        });
    }

    // Validates nameQuery. Falls back to full list if empty
    public LiveData<List<EventItem>> searchItemsByName(int userId, String nameQuery) {
        if (nameQuery == null || nameQuery.trim().isEmpty()) {
            return eventItemDao.getItemsByUser(userId);  // empty query = show all
        }
        return eventItemDao.searchItemsByName(userId, nameQuery.trim());
    }

    // Validates date range before hitting the DB
    public LiveData<List<EventItem>> getItemsByDateRange(int userId, long startDate, long endDate) {
        if (startDate > endDate) {
            throw new IllegalArgumentException("startDate must not be after endDate");
        }
        return eventItemDao.getItemsByDateRange(userId, startDate, endDate);
    }

    // Callback interfaces
    public interface InsertCallback {
        void onSuccess(int itemId);
        void onError(String error);
    }

    public interface BulkInsertCallback {
        void onSuccess(int count);
        void onError(String error);
    }

    public interface UpdateCallback {
        void onSuccess();
        void onError(String error);
    }

    public interface DeleteCallback {
        void onSuccess();
        void onError(String error);
    }

    public interface CountCallback {
        void onResult(int count);
    }
}