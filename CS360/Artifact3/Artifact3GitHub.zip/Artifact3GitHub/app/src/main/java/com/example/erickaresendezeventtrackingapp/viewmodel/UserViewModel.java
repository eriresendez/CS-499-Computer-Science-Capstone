package com.example.erickaresendezeventtrackingapp.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.erickaresendezeventtrackingapp.database.entity.User;
import com.example.erickaresendezeventtrackingapp.repository.UserRepository;

import java.util.List;

/**
 * ViewModel for User operations.
 * Survives configuration changes and manages UI-related data.
 * Provides clean separation between UI and data layers.
 */
public class UserViewModel extends AndroidViewModel {

    private final UserRepository repository;
    private final LiveData<List<User>> allUsers;

    public UserViewModel(@NonNull Application application) {
        super(application);
        repository = new UserRepository(application);
        allUsers = repository.getAllUsers();
    }

    /**
     * Get all users as LiveData
     */
    public LiveData<List<User>> getAllUsers() {
        return allUsers;
    }

    /**
     * Get user by username
     */
    public LiveData<User> getUserByUsername(String username) {
        return repository.getUserByUsername(username);
    }

    /**
     * Register a new user
     */
    public void registerUser(String username, String password, UserRepository.RegistrationCallback callback) {
        repository.registerUser(username, password, callback);
    }

    /**
     * Authenticate a user
     */
    public void authenticateUser(String username, String password, UserRepository.AuthenticationCallback callback) {
        repository.authenticateUser(username, password, callback);
    }

    /**
     * Check if username exists
     */
    public void checkUsernameExists(String username, UserRepository.ExistsCallback callback) {
        repository.checkUsernameExists(username, callback);
    }

    /**
     * Update user
     */
    public void updateUser(User user, UserRepository.UpdateCallback callback) {
        repository.updateUser(user, callback);
    }

    /**
     * Delete user
     */
    public void deleteUser(User user, UserRepository.DeleteCallback callback) {
        repository.deleteUser(user, callback);
    }
}