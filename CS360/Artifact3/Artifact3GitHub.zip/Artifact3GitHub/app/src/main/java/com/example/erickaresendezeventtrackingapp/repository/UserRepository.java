package com.example.erickaresendezeventtrackingapp.repository;

import android.app.Application;
import android.database.sqlite.SQLiteConstraintException;

import androidx.lifecycle.LiveData;

import com.example.erickaresendezeventtrackingapp.database.AppDatabase;
import com.example.erickaresendezeventtrackingapp.database.dao.UserDao;
import com.example.erickaresendezeventtrackingapp.database.entity.User;
import com.example.erickaresendezeventtrackingapp.util.PasswordHashUtil;

import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

/**
 * Repository for User operations.
 * Provides a clean API abstracting data source details from ViewModels.
 * Handles threading and business logic for user authentication.
 */
public class UserRepository {

    private final UserDao userDao;
    private final Executor executor;
    private final LiveData<List<User>> allUsers;

    public UserRepository(Application application) {
        AppDatabase database = AppDatabase.getInstance(application);
        userDao = database.userDao();
        executor = Executors.newSingleThreadExecutor();
        allUsers = userDao.getAllUsers();
    }

    /**
     * Get all users (LiveData for reactive updates)
     */
    public LiveData<List<User>> getAllUsers() {
        return allUsers;
    }

    /**
     * Get user by username
     */
    public LiveData<User> getUserByUsername(String username) {
        return userDao.getUserByUsername(username);
    }

    /**
     * Register a new user (async operation)
     * @param username Username
     * @param password Plain text password (will be hashed)
     * @param callback Callback for success/failure
     */
    public void registerUser(String username, String password, RegistrationCallback callback) {
        executor.execute(() -> {
            try {
                // Check if username already exists
                if (userDao.usernameExists(username)) {
                    callback.onError("Username already exists");
                    return;
                }

                // Hash the password
                String hashedPassword = PasswordHashUtil.hashPassword(password);

                // Create and insert user
                User user = new User(username, hashedPassword);
                long userId = userDao.insertUser(user);

                if (userId > 0) {
                    callback.onSuccess((int) userId);
                } else {
                    callback.onError("Failed to create user");
                }
            } catch (SQLiteConstraintException e) {
                callback.onError("Username already exists");
            } catch (Exception e) {
                callback.onError("Registration failed: " + e.getMessage());
            }
        });
    }

    /**
     * Authenticate a user (async operation)
     * @param username Username
     * @param password Plain text password
     * @param callback Callback for success/failure
     */
    public void authenticateUser(String username, String password, AuthenticationCallback callback) {
        executor.execute(() -> {
            try {
                // Fetch the user by username first so we can retrieve their stored salt
                User user = userDao.getUserByUsernameSync(username);

                if (user == null) {
                    callback.onFailure("Invalid username or password");
                    return;
                }

                // Now verify the plain text password against the stored salt:hash
                if (PasswordHashUtil.verifyPassword(password, user.getPasswordHash())) {
                    callback.onSuccess(user);
                } else {
                    callback.onFailure("Invalid username or password");
                }
            } catch (Exception e) {
                callback.onFailure("Authentication error: " + e.getMessage());
            }
        });
    }

    /**
     * Check if username exists
     * @param username Username to check
     * @param callback Callback with result
     */
    public void checkUsernameExists(String username, ExistsCallback callback) {
        executor.execute(() -> {
            boolean exists = userDao.usernameExists(username);
            callback.onResult(exists);
        });
    }

    /**
     * Update user information
     */
    public void updateUser(User user, UpdateCallback callback) {
        executor.execute(() -> {
            int rowsUpdated = userDao.updateUser(user);
            if (rowsUpdated > 0) {
                callback.onSuccess();
            } else {
                callback.onError("Failed to update user");
            }
        });
    }

    /**
     * Delete a user
     */
    public void deleteUser(User user, DeleteCallback callback) {
        executor.execute(() -> {
            int rowsDeleted = userDao.deleteUser(user);
            if (rowsDeleted > 0) {
                callback.onSuccess();
            } else {
                callback.onError("Failed to delete user");
            }
        });
    }

    // Callback interfaces
    public interface RegistrationCallback {
        void onSuccess(int userId);
        void onError(String error);
    }

    public interface AuthenticationCallback {
        void onSuccess(User user);
        void onFailure(String error);
    }

    public interface ExistsCallback {
        void onResult(boolean exists);
    }

    public interface UpdateCallback {
        void onSuccess();
        void onError(String error);
    }

    public interface DeleteCallback {
        void onSuccess();
        void onError(String error);
    }
}