package com.example.erickaresendezeventtrackingapp.database.entity;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

/**
 * Room Entity representing an Event Item in the database.
 * Replaces the old 'items' table from DatabaseHandler.
 * Includes foreign key relationship to User for data integrity.
 */
@Entity(tableName = "event_items",
        foreignKeys = @ForeignKey(
                entity = User.class,
                parentColumns = "user_id",
                childColumns = "user_id",
                onDelete = ForeignKey.CASCADE
        ),
        indices = {
                @Index(value = "user_id"),
                @Index(value = "item_name")
        })
public class EventItem {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "item_id")
    private int itemId;

    @NonNull
    @ColumnInfo(name = "item_name")
    private String itemName;

    @ColumnInfo(name = "quantity")
    private int quantity;

    @ColumnInfo(name = "user_id")
    private int userId;

    @ColumnInfo(name = "event_date")
    private long eventDate;

    @ColumnInfo(name = "description")
    private String description;

    public EventItem(@NonNull String itemName, int quantity, int userId) {
        // Validate all inputs explicitly before persisting
        // Reject blank names
        if (itemName.trim().isEmpty()) {
            throw new IllegalArgumentException("Item name must not be empty");
        }
        //quantity can't be negative
        if (quantity < 0) {
            throw new IllegalArgumentException("Quantity must be zero or greater");
        }
        //userId must be a real database ID
        if (userId <= 0) {
            throw new IllegalArgumentException("A valid user ID is required");
        }

        // .trim() removes accidental leading/trailing spaces before saving
        // so "  Meeting  " and "Meeting" don't become two separate items
        this.itemName = itemName.trim();  // Trim whitespace to prevent duplicates
        this.quantity = quantity;
        this.userId = userId;
        this.eventDate = System.currentTimeMillis();
        this.description = "";
    }

    // Getters and Setters
    public int getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    @NonNull
    public String getItemName() {
        return itemName;
    }

    public void setItemName(@NonNull String itemName) {
        this.itemName = itemName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public long getEventDate() {
        return eventDate;
    }

    public void setEventDate(long eventDate) {
        this.eventDate = eventDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}