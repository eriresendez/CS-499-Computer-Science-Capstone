package com.example.erickaresendezeventtrackingapp.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.erickaresendezeventtrackingapp.database.entity.EventItem;
import com.example.erickaresendezeventtrackingapp.repository.EventItemRepository;

import java.util.List;

/**
 * ViewModel for EventItem operations.
 * Manages UI-related data and survives configuration changes.
 */
public class EventItemViewModel extends AndroidViewModel {

    private final EventItemRepository repository;
    private final LiveData<List<EventItem>> allItems;

    public EventItemViewModel(@NonNull Application application) {
        super(application);
        repository = new EventItemRepository(application);
        allItems = repository.getAllItems();
    }

    /**
     * Get all items
     */
    public LiveData<List<EventItem>> getAllItems() {
        return allItems;
    }

    /**
     * Get items for specific user
     */
    public LiveData<List<EventItem>> getItemsByUser(int userId) {
        return repository.getItemsByUser(userId);
    }

    /**
     * Get item by ID
     */
    public LiveData<EventItem> getItemById(int itemId) {
        return repository.getItemById(itemId);
    }

    /**
     * Insert new item
     */
    public void insertItem(EventItem item, EventItemRepository.InsertCallback callback) {
        repository.insertItem(item, callback);
    }

    /**
     * Insert multiple items
     */
    public void insertItems(List<EventItem> items, EventItemRepository.BulkInsertCallback callback) {
        repository.insertItems(items, callback);
    }

    /**
     * Update item
     */
    public void updateItem(EventItem item, EventItemRepository.UpdateCallback callback) {
        repository.updateItem(item, callback);
    }

    /**
     * Update item quantity by name
     */
    public void updateItemQuantity(String itemName, int newQuantity, EventItemRepository.UpdateCallback callback) {
        repository.updateItemQuantity(itemName, newQuantity, callback);
    }

    /**
     * Delete item
     */
    public void deleteItem(EventItem item, EventItemRepository.DeleteCallback callback) {
        repository.deleteItem(item, callback);
    }

    /**
     * Delete item by name
     */
    public void deleteItemByName(String itemName, EventItemRepository.DeleteCallback callback) {
        repository.deleteItemByName(itemName, callback);
    }

    /**
     * Delete all items for a user
     */
    public void deleteItemsByUser(int userId, EventItemRepository.DeleteCallback callback) {
        repository.deleteItemsByUser(userId, callback);
    }

    /**
     * Get item count for user
     */
    public void getItemCountByUser(int userId, EventItemRepository.CountCallback callback) {
        repository.getItemCountByUser(userId, callback);
    }

    /**
     * Exposes search to the UI layer
     * Documents the empty-query fallback behavior
     */
    public LiveData<List<EventItem>> searchItemsByName(int userId, String nameQuery) {
        return repository.searchItemsByName(userId, nameQuery);
    }

    /**
     * Exposes date range filter to the UI layer
     */
    public LiveData<List<EventItem>> getItemsByDateRange(int userId, long startDate, long endDate) {
        return repository.getItemsByDateRange(userId, startDate, endDate);
    }
}