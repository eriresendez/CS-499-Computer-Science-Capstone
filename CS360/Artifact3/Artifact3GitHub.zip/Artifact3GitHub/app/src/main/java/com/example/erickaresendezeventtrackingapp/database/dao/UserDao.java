package com.example.erickaresendezeventtrackingapp.database.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.erickaresendezeventtrackingapp.database.entity.User;

import java.util.List;

/**
 * Data Access Object for User operations.
 * Provides type-safe, compile-time verified database queries.
 */
@Dao
public interface UserDao {

    /**
     * Insert a new user. Will throw exception if username already exists.
     * @param user User to insert
     * @return Row ID of inserted user
     */
    @Insert(onConflict = OnConflictStrategy.ABORT)
    long insertUser(User user);

    /**
     * Get a user by username (returns LiveData for reactive updates)
     * @param username Username to search for
     * @return LiveData containing the user, or null if not found
     */
    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    LiveData<User> getUserByUsername(String username);

    /**
     * Authenticate a user with username and password hash
     * @param username Username
     * @param passwordHash Hashed password
     * @return User object if credentials match, null otherwise
     */
    @Query("SELECT * FROM users WHERE username = :username AND password_hash = :passwordHash LIMIT 1")
    User authenticateUser(String username, String passwordHash);

    /**
     * Check if a username already exists
     * @param username Username to check
     * @return true if username exists, false otherwise
     */
    @Query("SELECT EXISTS(SELECT 1 FROM users WHERE username = :username)")
    boolean usernameExists(String username);

    /**
     * Get all users (for admin functionality)
     * @return LiveData list of all users
     */
    @Query("SELECT * FROM users ORDER BY created_at DESC")
    LiveData<List<User>> getAllUsers();

    /**
     * Update an existing user
     * @param user User to update
     * @return Number of rows updated
     */
    @Update
    int updateUser(User user);

    /**
     * Delete a user
     * @param user User to delete
     * @return Number of rows deleted
     */
    @Delete
    int deleteUser(User user);

    /**
     * Delete all users (for testing/reset functionality)
     */
    @Query("DELETE FROM users")
    void deleteAllUsers();

    // Synchronous lookup needed for authentication — called from background thread in repository
    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    User getUserByUsernameSync(String username);
}