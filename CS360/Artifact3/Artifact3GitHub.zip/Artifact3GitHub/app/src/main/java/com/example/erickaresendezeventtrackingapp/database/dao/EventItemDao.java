package com.example.erickaresendezeventtrackingapp.database.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.erickaresendezeventtrackingapp.database.entity.EventItem;

import java.util.List;

/**
 * Data Access Object for EventItem operations.
 * Replaces manual cursor operations from DatabaseHandler.
 */
@Dao
public interface EventItemDao {

    /**
     * Insert a new event item
     * @param item EventItem to insert
     * @return Row ID of inserted item
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insertItem(EventItem item);

    /**
     * Insert multiple items at once (bulk operation)
     * @param items List of items to insert
     * @return Array of row IDs
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long[] insertItems(List<EventItem> items);

    /**
     * Get all items for a specific user (LiveData for reactive UI updates)
     * @param userId User ID to filter by
     * @return LiveData list of user's event items
     */
    @Query("SELECT * FROM event_items WHERE user_id = :userId ORDER BY event_date DESC")
    LiveData<List<EventItem>> getItemsByUser(int userId);

    /**
     * Get all items (for current implementation compatibility)
     * @return LiveData list of all event items
     */
    @Query("SELECT * FROM event_items ORDER BY event_date DESC")
    LiveData<List<EventItem>> getAllItems();

    /**
     * Get a specific item by name
     * @param itemName Name of the item
     * @return The EventItem, or null if not found
     */
    @Query("SELECT * FROM event_items WHERE item_name = :itemName LIMIT 1")
    EventItem getItemByName(String itemName);

    /**
     * Get a specific item by ID
     * @param itemId Item ID
     * @return LiveData containing the item
     */
    @Query("SELECT * FROM event_items WHERE item_id = :itemId")
    LiveData<EventItem> getItemById(int itemId);

    /**
     * Update an existing item
     * @param item Item to update
     * @return Number of rows updated
     */
    @Update
    int updateItem(EventItem item);

    /**
     * Update item quantity by name (for backward compatibility)
     * @param itemName Name of item to update
     * @param newQuantity New quantity value
     * @return Number of rows updated
     */
    @Query("UPDATE event_items SET quantity = :newQuantity WHERE item_name = :itemName")
    int updateItemQuantity(String itemName, int newQuantity);

    /**
     * Delete a specific item
     * @param item Item to delete
     * @return Number of rows deleted
     */
    @Delete
    int deleteItem(EventItem item);

    /**
     * Delete item by name (for backward compatibility)
     * @param itemName Name of item to delete
     * @return Number of rows deleted
     */
    @Query("DELETE FROM event_items WHERE item_name = :itemName")
    int deleteItemByName(String itemName);

    /**
     * Delete all items for a specific user
     * @param userId User ID
     * @return Number of rows deleted
     */
    @Query("DELETE FROM event_items WHERE user_id = :userId")
    int deleteItemsByUser(int userId);

    /**
     * Delete all items (for testing/reset)
     */
    @Query("DELETE FROM event_items")
    void deleteAllItems();

    /**
     * Get count of items for a user
     * @param userId User ID
     * @return Number of items
     */
    @Query("SELECT COUNT(*) FROM event_items WHERE user_id = :userId")
    int getItemCountByUser(int userId);


    /**
     * Search by partial name for a user.
     * Explains index trade-off in Javadoc
    */
    @Query("SELECT * FROM event_items WHERE user_id = :userId " +
            "AND item_name LIKE '%' || :nameQuery || '%' ORDER BY item_name ASC")
    LiveData<List<EventItem>> searchItemsByName(int userId, String nameQuery);

    /**
     * Date range filter
     * Explains secondary index trade-off in Javadoc
     * */
    @Query("SELECT * FROM event_items WHERE user_id = :userId " +
            "AND event_date BETWEEN :startDate AND :endDate ORDER BY event_date ASC")
    LiveData<List<EventItem>> getItemsByDateRange(int userId, long startDate, long endDate);
}