package com.example.erickaresendezeventtrackingapp;


public class Event {
    private String name;
    private String date; // Add date field
    private String description; // Add description field

    // Constructor
    public Event(String name, String date, String description) {
        this.name = name;
        this.date = date;
        this.description = description;
    }

    // Getters
    public String getName() {
        return name;
    }

    public String getDate() {
        return date;
    }

    public String getDescription() {
        return description;
    }
}
