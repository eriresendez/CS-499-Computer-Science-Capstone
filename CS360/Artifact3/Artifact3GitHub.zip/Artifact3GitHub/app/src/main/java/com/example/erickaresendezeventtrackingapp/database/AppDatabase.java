package com.example.erickaresendezeventtrackingapp.database;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.example.erickaresendezeventtrackingapp.database.dao.EventItemDao;
import com.example.erickaresendezeventtrackingapp.database.dao.UserDao;
import com.example.erickaresendezeventtrackingapp.database.entity.EventItem;
import com.example.erickaresendezeventtrackingapp.database.entity.User;

/**
 * Main Room Database class for the Event Tracking application.
 * Implements singleton pattern to ensure only one database instance exists.
 *
 * Security improvements over raw SQLite:
 * - Compile-time query verification prevents SQL injection
 * - Type-safe operations reduce runtime errors
 * - Automatic connection management prevents leaks
 * - Structured migrations preserve data integrity
 */
@Database(entities = {User.class, EventItem.class}, version = 2, exportSchema = true)
public abstract class AppDatabase extends RoomDatabase {

    private static final String DATABASE_NAME = "AppDatabase.db";
    private static volatile AppDatabase INSTANCE;

    // Abstract methods to get DAOs
    public abstract UserDao userDao();
    public abstract EventItemDao eventItemDao();

    /**
     * Get singleton instance of the database
     * @param context Application context
     * @return AppDatabase instance
     */
    public static AppDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                                    context.getApplicationContext(),
                                    AppDatabase.class,
                                    DATABASE_NAME
                            )
                            .addMigrations(MIGRATION_1_2)  // Add migration for schema changes
                            .fallbackToDestructiveMigration() // clears corrupt/mismatched schema during development
                            .build();
                }
            }
        }
        return INSTANCE;
    }

    /**
     * Migration from version 1 (old SQLite) to version 2 (Room with enhancements)
     * This preserves existing user data during the upgrade.
     */
    static final Migration MIGRATION_1_2 = new Migration(1, 2) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {
            // Step 1: Create new users table with enhanced schema
            database.execSQL("CREATE TABLE IF NOT EXISTS users_new (" +
                    "user_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                    "username TEXT NOT NULL, " +
                    "password_hash TEXT NOT NULL, " +
                    "created_at INTEGER NOT NULL DEFAULT 0)");

            // Step 2: Copy data from old users table if it exists
            database.execSQL("INSERT INTO users_new (username, password_hash, created_at) " +
                    "SELECT username, password, 0 FROM users");

            // Step 3: Drop old table and rename new table
            database.execSQL("DROP TABLE IF EXISTS users");
            database.execSQL("ALTER TABLE users_new RENAME TO users");

            // Step 4: Create unique index on username
            database.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_users_username ON users(username)");

            // Step 5: Create new event_items table with foreign key
            database.execSQL("CREATE TABLE IF NOT EXISTS event_items (" +
                    "item_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                    "item_name TEXT NOT NULL, " +
                    "quantity INTEGER NOT NULL, " +
                    "user_id INTEGER NOT NULL, " +
                    "event_date INTEGER NOT NULL DEFAULT 0, " +
                    "description TEXT, " +
                    "FOREIGN KEY(user_id) REFERENCES users(user_id) ON DELETE CASCADE)");

            // Step 6: Copy data from old items table if it exists
            // Note: We'll assign items to user_id = 1 (first user) as a default
            database.execSQL("INSERT INTO event_items (item_name, quantity, user_id, event_date) " +
                    "SELECT item_name, quantity, 1, 0 FROM items WHERE EXISTS(SELECT 1 FROM users LIMIT 1)");

            // Step 7: Drop old items table
            database.execSQL("DROP TABLE IF EXISTS items");

            // Step 8: Create indices for better query performance
            database.execSQL("CREATE INDEX IF NOT EXISTS index_event_items_user_id ON event_items(user_id)");
            database.execSQL("CREATE INDEX IF NOT EXISTS index_event_items_item_name ON event_items(item_name)");
        }
    };

    /**
     * Close the database instance (for testing or app shutdown)
     */
    public static void destroyInstance() {
        if (INSTANCE != null) {
            INSTANCE.close();
            INSTANCE = null;
        }
    }
}