package com.example.erickaresendezeventtrackingapp;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsPermissionActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 1;
    private SwitchCompat smsPermissionSwitch;
    private TextView notificationStatusTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission1); // sets layout for this activity

        smsPermissionSwitch = findViewById(R.id.switch1); // references switch from xml
        notificationStatusTextView = findViewById(R.id.notificationStatus); // references textview from xml

        // check if sms permission is granted, set switch and status text accordingly
        if (isSmsPermissionGranted()) {
            smsPermissionSwitch.setChecked(true);
            updateNotificationStatusText(true);
        } else {
            smsPermissionSwitch.setChecked(false);
            updateNotificationStatusText(false);
        }

        // handle switch toggle action
        smsPermissionSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    // if user enables switch, check and request sms permission
                    if (!isSmsPermissionGranted()) {
                        requestSmsPermission();
                    } else {
                        updateNotificationStatusText(true);
                    }
                } else {
                    // if user disables switch, turn off sms notifications
                    updateNotificationStatusText(false);
                    Toast.makeText(SmsPermissionActivity.this, "SMS notifications turned off", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // check if sms permission is granted
    private boolean isSmsPermissionGranted() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    // request sms permission from user
    private void requestSmsPermission() {
        // show rationale for permission if previously denied
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
            Toast.makeText(this, "SMS permission is required to send notifications.", Toast.LENGTH_LONG).show();
        }
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
    }

    // handle permission request result
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
                smsPermissionSwitch.setChecked(true);
                updateNotificationStatusText(true);
            } else {
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
                smsPermissionSwitch.setChecked(false);
                updateNotificationStatusText(false);
            }
        }
    }

    // update notification status based on permission and switch
    private void updateNotificationStatusText(boolean isEnabled) {
        if (isEnabled) {
            notificationStatusTextView.setText(R.string.notifications_enabled);
        } else {
            notificationStatusTextView.setText(R.string.notifications_currently_disabled);
        }
    }
}
