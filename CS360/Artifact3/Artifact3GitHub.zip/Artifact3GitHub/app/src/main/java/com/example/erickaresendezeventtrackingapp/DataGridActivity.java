/**
 * DataGridActivity — displays the logged-in user's events in a card-style list.
 *
 * Architecture role (MVVM):
 * Observes EventItemViewModel LiveData filtered by the current user's ID,
 * so each account only sees its own events.
 *
 * Search and date-range filter allow the user to find specific events quickly.
 */

package com.example.erickaresendezeventtrackingapp;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;

import com.example.erickaresendezeventtrackingapp.database.entity.EventItem;
import com.example.erickaresendezeventtrackingapp.viewmodel.EventItemViewModel;
import com.example.erickaresendezeventtrackingapp.repository.EventItemRepository;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DataGridActivity extends AppCompatActivity {
    private EventItemViewModel eventItemViewModel;
    private LinearLayout gridEvents;
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private EditText searchField;

    private int currentUserId;
    private List<EventItem> allLoadedItems = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_grid);

        // Get the logged-in user's ID from SharedPreferences
        SharedPreferences prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);
        currentUserId = prefs.getInt("current_user_id", -1);

        // Initialize ViewModel
        eventItemViewModel = new ViewModelProvider(this).get(EventItemViewModel.class);

        // Set up toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Set up navigation drawer with hamburger toggle
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar,
                R.string.navigation_drawer_open,
                R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        // Drawer menu item clicks
        navigationView.setNavigationItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) {
                // already here
            } else if (id == R.id.nav_sms) {
                startActivity(new Intent(this, SmsPermissionActivity.class));
            } else if (id == R.id.nav_logout) {
                logout();
            }
            drawerLayout.closeDrawers();
            return true;
        });

        // Bind UI views
        gridEvents = findViewById(R.id.gridEvents);
        FloatingActionButton addEventButton = findViewById(R.id.floatingActionButton);
        searchField = findViewById(R.id.searchField);
        Button searchButton = findViewById(R.id.searchButton);
        Button showAllButton = findViewById(R.id.showAllButton);
        Button dateRangeButton = findViewById(R.id.dateRangeButton);

        // Add event button
        addEventButton.setOnClickListener(v ->
                startActivity(new Intent(DataGridActivity.this, AddingData.class)));

        // Search by name
        searchButton.setOnClickListener(v -> {
            String term = searchField.getText().toString().trim();
            if (!term.isEmpty()) {
                List<EventItem> filtered = new ArrayList<>();
                for (EventItem item : allLoadedItems) {
                    if (item.getItemName().toLowerCase().contains(term.toLowerCase())) {
                        filtered.add(item);
                    }
                }
                updateGrid(filtered);
                Toast.makeText(this, "Found " + filtered.size() + " event(s)", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Please enter a search term", Toast.LENGTH_SHORT).show();
            }
        });

        // Show all — clears search and resets grid
        showAllButton.setOnClickListener(v -> {
            searchField.setText("");
            updateGrid(allLoadedItems);
        });

        // Date range picker
        dateRangeButton.setOnClickListener(v -> showDateRangePicker());

        // Observe only THIS user's events from the database
        observeUserEvents();
    }

    /**
     * Observes LiveData filtered to the current user's ID.
     * This ensures events from other accounts are never shown here.
     */
    private void observeUserEvents() {
        if (currentUserId == -1) {
            Toast.makeText(this, "Session error, please log in again", Toast.LENGTH_LONG).show();
            logout();
            return;
        }
        // Having issues when making new accounts and logging in, the users could all view the same events
        // getItemsByUser() instead of getAllItems(). Scopes events to logged-in user to solve this issue
        eventItemViewModel.getItemsByUser(currentUserId).observe(this, items -> {
            if (items != null) {
                allLoadedItems.clear();
                allLoadedItems.addAll(items);
                updateGrid(allLoadedItems);
            }
        });
    }

    /**
     * Renders event cards. Each card shows name, date, description with Edit and Delete buttons.
     */
    private void updateGrid(List<EventItem> events) {
        gridEvents.removeAllViews();

        if (events.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("No events to display");
            empty.setPadding(20, 40, 20, 20);
            empty.setGravity(Gravity.CENTER);
            empty.setTextColor(Color.parseColor("#888888"));
            gridEvents.addView(empty);
            return;
        }

        for (EventItem item : events) {

            // Outer card
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setBackgroundColor(Color.WHITE);
            LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            cardParams.setMargins(0, 0, 0, 12);
            card.setLayoutParams(cardParams);
            card.setPadding(16, 16, 16, 12);
            card.setElevation(4f);

            // Info row: Name | Date | Description
            LinearLayout infoRow = new LinearLayout(this);
            infoRow.setOrientation(LinearLayout.HORIZONTAL);
            infoRow.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT));

            TextView nameView = new TextView(this);
            nameView.setText(item.getItemName());
            nameView.setTypeface(null, Typeface.BOLD);
            nameView.setTextColor(Color.parseColor("#235391"));
            nameView.setTextSize(14f);
            nameView.setPadding(0, 0, 8, 0);
            nameView.setLayoutParams(new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.WRAP_CONTENT, 1.2f));

            TextView dateView = new TextView(this);
            dateView.setText(formatDate(item.getEventDate()));
            dateView.setTextColor(Color.parseColor("#505050"));
            dateView.setTextSize(13f);
            dateView.setPadding(0, 0, 8, 0);
            dateView.setLayoutParams(new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f));

            TextView descView = new TextView(this);
            descView.setText(item.getDescription() != null ? item.getDescription() : "");
            descView.setTextColor(Color.parseColor("#505050"));
            descView.setTextSize(13f);
            descView.setLayoutParams(new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.WRAP_CONTENT, 1.5f));

            infoRow.addView(nameView);
            infoRow.addView(dateView);
            infoRow.addView(descView);

            // Divider line
            android.view.View divider = new android.view.View(this);
            LinearLayout.LayoutParams divParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 1);
            divParams.setMargins(0, 10, 0, 8);
            divider.setLayoutParams(divParams);
            divider.setBackgroundColor(Color.parseColor("#E0E0E0"));

            // Button row
            LinearLayout btnRow = new LinearLayout(this);
            btnRow.setOrientation(LinearLayout.HORIZONTAL);
            btnRow.setGravity(Gravity.END);
            btnRow.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT));

            Button deleteBtn = new Button(this);
            deleteBtn.setText("Delete");
            deleteBtn.setTextColor(Color.WHITE);
            deleteBtn.setBackgroundTintList(
                    android.content.res.ColorStateList.valueOf(Color.parseColor("#C62828")));
            deleteBtn.setOnClickListener(v -> deleteEvent(item));

            btnRow.addView(deleteBtn);

            // Assemble card
            card.addView(infoRow);
            card.addView(divider);
            card.addView(btnRow);

            gridEvents.addView(card);
        }
    }

    private String formatDate(long timestamp) {
        if (timestamp == 0) return "No date";
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
        return sdf.format(new Date(timestamp));
    }

    private void showDateRangePicker() {
        Calendar today = Calendar.getInstance();
        DatePickerDialog startPicker = new DatePickerDialog(this,
                (view, y, m, d) -> {
                    long startMs = toTimestamp(y, m, d);
                    DatePickerDialog endPicker = new DatePickerDialog(this,
                            (v2, y2, m2, d2) -> {
                                long endMs = toTimestamp(y2, m2, d2) + 86400000L; // inclusive
                                List<EventItem> filtered = new ArrayList<>();
                                for (EventItem item : allLoadedItems) {
                                    if (item.getEventDate() >= startMs && item.getEventDate() <= endMs) {
                                        filtered.add(item);
                                    }
                                }
                                updateGrid(filtered);
                                Toast.makeText(this, "Found " + filtered.size() + " event(s)", Toast.LENGTH_SHORT).show();
                            },
                            today.get(Calendar.YEAR), today.get(Calendar.MONTH), today.get(Calendar.DAY_OF_MONTH));
                    endPicker.setTitle("Select End Date");
                    endPicker.show();
                },
                today.get(Calendar.YEAR), today.get(Calendar.MONTH), today.get(Calendar.DAY_OF_MONTH));
        startPicker.setTitle("Select Start Date");
        startPicker.show();
    }

    private long toTimestamp(int year, int month, int day) {
        Calendar cal = Calendar.getInstance();
        cal.set(year, month, day, 0, 0, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTimeInMillis();
    }

    private void deleteEvent(EventItem item) {
        eventItemViewModel.deleteItem(item, new EventItemRepository.DeleteCallback() {
            @Override
            public void onSuccess() {
                runOnUiThread(() ->
                        Toast.makeText(DataGridActivity.this, "Event deleted", Toast.LENGTH_SHORT).show());
            }
            @Override
            public void onError(String error) {
                runOnUiThread(() ->
                        Toast.makeText(DataGridActivity.this, "Error: " + error, Toast.LENGTH_SHORT).show());
            }
        });
    }

    private void logout() {
        Toast.makeText(this, R.string.toast_logged_out, Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(navigationView)) {
            drawerLayout.closeDrawers();
        } else {
            super.onBackPressed();
        }
    }
}
