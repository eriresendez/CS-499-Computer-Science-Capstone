/**
 * Utility class for password hashing operations.
 * Centralizes security-critical code for easier auditing and updates.
 *
 * Uses SHA-256 with a unique per-user salt to prevent rainbow table attacks.
 * Salt and hash are stored together in the format "salt:hash".
 * Two users with identical passwords will have different stored hashes.
 */

package com.example.erickaresendezeventtrackingapp.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

public class PasswordHashUtil {

    private static final String DELIMITER = ":";

    /**
     * Hash a password using SHA-256
     * @param password Plain text password
     * @return Hexadecimal string representation of the hash
     * @throws RuntimeException if SHA-256 algorithm is not available
     */
    public static String hashPassword(String password) {
        // Reject null/empty passwords explicitly instead of hashing them
        if (password == null || password.isEmpty()) {
            throw new IllegalArgumentException("Password must not be null or empty");
        }

        // Generate a cryptographically random 16-byte salt per password
        SecureRandom random = new SecureRandom();
        byte[] salt = new byte[16];
        random.nextBytes(salt);
        String saltBase64 = Base64.getEncoder().encodeToString(salt);

        // Return "salt:hash" so the salt is recoverable at verification time
        String hash = computeHash(password, saltBase64);
        return saltBase64 + DELIMITER + hash;
    }

    /**
     * Verify a password against a stored hash
     * @param password Plain text password to verify
     * @param storedHash The stored hash to compare against
     * @return true if password matches, false otherwise
     */

    public static boolean verifyPassword(String password, String storedHash) {
        // Null guard; previously would throw a NullPointerException
        if (password == null || storedHash == null) {
            return false;
        }

        // Extract salt from stored "salt:hash" string and re-hash input
        String[] parts = storedHash.split(DELIMITER, 2);
        if (parts.length != 2) {
            // Accounts created before salting still work
            String legacyHash = computeHashLegacy(password);
            return legacyHash.equals(storedHash);
        }

        String saltBase64 = parts[0];
        String expectedHash = parts[1];
        String actualHash = computeHash(password, saltBase64);
        return actualHash.equals(expectedHash);
    }

    // Private helper: hashes salted bytes with SHA-256
    private static String computeHash(String password, String saltBase64) {
        try {
            byte[] salt = Base64.getDecoder().decode(saltBase64);
            byte[] passwordBytes = password.getBytes();
            byte[] saltedPassword = new byte[salt.length + passwordBytes.length];
            System.arraycopy(salt, 0, saltedPassword, 0, salt.length);
            System.arraycopy(passwordBytes, 0, saltedPassword, salt.length, passwordBytes.length);
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = digest.digest(saltedPassword);
            return bytesToHex(hashedBytes);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 algorithm not available", e);
        }
    }

    private static String computeHashLegacy(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            return bytesToHex(digest.digest(password.getBytes()));
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 algorithm not available", e);
        }
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder hexString = new StringBuilder();
        for (byte b : bytes) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }
        return hexString.toString();
    }
}