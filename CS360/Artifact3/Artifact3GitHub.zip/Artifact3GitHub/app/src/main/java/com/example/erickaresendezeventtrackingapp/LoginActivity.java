package com.example.erickaresendezeventtrackingapp;

import android.content.Intent; // intent import
import android.os.Bundle; // bundle import
import android.view.View; // view import
import android.widget.Button; // button import
import android.widget.EditText; // edittext import
import android.widget.TextView; // textview import
import android.widget.Toast; // toast import
import androidx.appcompat.app.AlertDialog; // alertdialog import
import androidx.appcompat.app.AppCompatActivity; // appcompat activity import
import android.content.SharedPreferences;
import androidx.lifecycle.ViewModelProvider;
import com.example.erickaresendezeventtrackingapp.viewmodel.UserViewModel;
import com.example.erickaresendezeventtrackingapp.repository.UserRepository;
import com.example.erickaresendezeventtrackingapp.database.entity.User;

public class LoginActivity extends AppCompatActivity {
    // initialize UI components
    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private TextView forgotPassword;
    private Button createAccountButton; // declare createAccountButton

    // hardcoded credentials for demonstration (replace with actual credentials or authentication method)
    // private static final String VALID_USERNAME = "user1@example.com"; // valid username
    // private static final String VALID_PASSWORD = "p@ssword123!"; // valid password
    
    // Declare ViewModel as class field
    private UserViewModel userViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize ViewModel here
        userViewModel = new ViewModelProvider(this).get(UserViewModel.class);

        // Link the UI components
        usernameEditText = findViewById(R.id.Username);
        passwordEditText = findViewById(R.id.Password);
        loginButton = findViewById(R.id.LoginButton);
        forgotPassword = findViewById(R.id.forgotPassword);
        createAccountButton = findViewById(R.id.createAccountButton);

        // Set click listener for the login button
        loginButton.setOnClickListener(v -> loginUser());

        // Set click listener for the forgot password text
        forgotPassword.setOnClickListener(v -> showResetPasswordDialog());

        // Set click listener for the create account button
        createAccountButton.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, CreateAccountActivity.class);
            startActivity(intent);
        });
    }

    // Method to handle user login
    private void loginUser() {
        // REMOVED: Lines 62 and 79 that incorrectly declared ViewModel

        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        // Validate input
        if (username.isEmpty()) {
            Toast.makeText(this, "Please enter your username", Toast.LENGTH_SHORT).show();
            usernameEditText.requestFocus();
            return;
        }

        if (password.isEmpty()) {
            Toast.makeText(this, "Please enter your password", Toast.LENGTH_SHORT).show();
            passwordEditText.requestFocus();
            return;
        }

        // Authenticate user using ViewModel (already initialized in onCreate)
        userViewModel.authenticateUser(username, password, new UserRepository.AuthenticationCallback() {
            @Override
            public void onSuccess(User user) {
                runOnUiThread(() -> {
                    // Store user session
                    SharedPreferences prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);
                    prefs.edit().putInt("current_user_id", user.getUserId()).apply();
                    prefs.edit().putString("current_username", user.getUsername()).apply();

                    Toast.makeText(LoginActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(LoginActivity.this, DataGridActivity.class);
                    startActivity(intent);
                    finish();
                });
            }

            @Override
            public void onFailure(String error) {
                runOnUiThread(() -> {
                    Toast.makeText(LoginActivity.this, "Login failed: " + error, Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    // Method to show reset password dialog
    private void showResetPasswordDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Reset Password");

        // Create an input field
        final EditText input = new EditText(this);
        input.setHint("Enter your email");
        builder.setView(input);

        // Set positive button for dialog
        builder.setPositiveButton("Submit", (dialog, which) -> {
            String email = input.getText().toString().trim();

            if (email.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Please enter your email", Toast.LENGTH_SHORT).show();
            } else {
                // Implement your password reset logic here
                Toast.makeText(LoginActivity.this, "Reset password link sent to " + email, Toast.LENGTH_SHORT).show();
            }
        });

        // Set negative button for dialog
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        // Show the dialog
        builder.show();
    }
}
