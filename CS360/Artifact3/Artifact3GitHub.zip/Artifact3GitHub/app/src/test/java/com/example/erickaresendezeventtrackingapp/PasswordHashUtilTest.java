package com.example.erickaresendezeventtrackingapp;

import com.example.erickaresendezeventtrackingapp.util.PasswordHashUtil;
import com.example.erickaresendezeventtrackingapp.database.entity.EventItem;

import org.junit.Test;
import static org.junit.Assert.*;

public class PasswordHashUtilTest {

    // Password hashing tests

    @Test
    public void hashPassword_returnsNonNullNonEmptyString() {
        String hash = PasswordHashUtil.hashPassword("myPassword123");
        assertNotNull(hash);
        assertFalse(hash.isEmpty());
    }

    @Test
    public void verifyPassword_correctPasswordReturnsTrue() {
        String hash = PasswordHashUtil.hashPassword("correctPassword");
        assertTrue(PasswordHashUtil.verifyPassword("correctPassword", hash));
    }

    @Test
    public void verifyPassword_wrongPasswordReturnsFalse() {
        String hash = PasswordHashUtil.hashPassword("correctPassword");
        assertFalse(PasswordHashUtil.verifyPassword("wrongPassword", hash));
    }

    @Test
    public void hashPassword_samePasswordProducesDifferentHashes() {
        // Salting ensures two identical passwords produce different stored hashes,
        // preventing an attacker from identifying shared passwords via hash comparison.
        String hash1 = PasswordHashUtil.hashPassword("samePassword");
        String hash2 = PasswordHashUtil.hashPassword("samePassword");
        assertNotEquals(
                "Identical passwords must produce different hashes due to unique salts",
                hash1, hash2
        );
    }

    @Test(expected = IllegalArgumentException.class)
    public void hashPassword_emptyPasswordThrowsException() {
        // Empty passwords are a security risk; the utility must reject them.
        PasswordHashUtil.hashPassword("");
    }

    @Test(expected = IllegalArgumentException.class)
    public void hashPassword_nullPasswordThrowsException() {
        PasswordHashUtil.hashPassword(null);
    }

    @Test
    public void verifyPassword_nullInputsReturnFalse() {
        assertFalse(PasswordHashUtil.verifyPassword(null, "someHash"));
        assertFalse(PasswordHashUtil.verifyPassword("password", null));
    }

    // --- EventItem validation tests ---

    @Test
    public void eventItem_validInputsConstructsSuccessfully() {
        EventItem item = new EventItem("Team Meeting", 1, 42);
        assertEquals("Team Meeting", item.getItemName());
        assertEquals(1, item.getQuantity());
        assertEquals(42, item.getUserId());
    }

    @Test
    public void eventItem_leadingTrailingSpacesTrimmed() {
        // Prevents duplicate items caused by accidental whitespace differences
        EventItem item = new EventItem("  Trimmed Name  ", 5, 1);
        assertEquals("Trimmed Name", item.getItemName());
    }

    @Test(expected = IllegalArgumentException.class)
    public void eventItem_emptyNameThrowsException() {
        new EventItem("", 1, 1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void eventItem_blankNameThrowsException() {
        new EventItem("   ", 1, 1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void eventItem_negativeQuantityThrowsException() {
        new EventItem("Valid Name", -1, 1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void eventItem_zeroUserIdThrowsException() {
        // userId 0 is invalid — Room auto-generates from 1 upward
        new EventItem("Valid Name", 1, 0);
    }

    @Test
    public void eventItem_zeroQuantityIsAllowed() {
        // Zero quantity is a valid state (e.g., item registered but not yet stocked)
        EventItem item = new EventItem("Empty Stock", 0, 1);
        assertEquals(0, item.getQuantity());
    }
}

