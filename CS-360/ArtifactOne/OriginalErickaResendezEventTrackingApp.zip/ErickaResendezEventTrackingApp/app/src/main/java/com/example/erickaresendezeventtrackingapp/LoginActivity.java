package com.example.erickaresendezeventtrackingapp;

import android.content.Intent; // intent import
import android.os.Bundle; // bundle import
import android.view.View; // view import
import android.widget.Button; // button import
import android.widget.EditText; // edittext import
import android.widget.TextView; // textview import
import android.widget.Toast; // toast import
import androidx.appcompat.app.AlertDialog; // alertdialog import
import androidx.appcompat.app.AppCompatActivity; // appcompat activity import

public class LoginActivity extends AppCompatActivity {
    // initialize UI components
    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private TextView forgotPassword;
    private Button createAccountButton; // declare createAccountButton

    // hardcoded credentials for demonstration (replace with actual credentials or authentication method)
    private static final String VALID_USERNAME = "user1@example.com"; // valid username
    private static final String VALID_PASSWORD = "p@ssword123!"; // valid password

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login); // set the layout

        // link the UI components
        usernameEditText = findViewById(R.id.Username);
        passwordEditText = findViewById(R.id.Password);
        loginButton = findViewById(R.id.LoginButton);
        forgotPassword = findViewById(R.id.forgotPassword);
        createAccountButton = findViewById(R.id.createAccountButton); // link createAccountButton

        // set click listener for the login button
        loginButton.setOnClickListener(v -> loginUser()); // call login method

        // set click listener for the forgot password text
        forgotPassword.setOnClickListener(v -> showResetPasswordDialog()); // call reset password dialog

        // set click listener for the create account button
        createAccountButton.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, CreateAccountActivity.class);
            startActivity(intent);
        });
    }

    // method to handle user login
    private void loginUser() {
        String username = usernameEditText.getText().toString().trim(); // get username
        String password = passwordEditText.getText().toString().trim(); // get password

        // validate input
        if (username.isEmpty()) {
            Toast.makeText(this, "please enter your username", Toast.LENGTH_SHORT).show(); // show error
            return; // exit method
        }

        if (password.isEmpty()) {
            Toast.makeText(this, "please enter your password", Toast.LENGTH_SHORT).show(); // show error
            return; // exit method
        }

        // authenticate user
        if (username.equals(VALID_USERNAME) && password.equals(VALID_PASSWORD)) {
            // login successful
            Toast.makeText(this, "login successful", Toast.LENGTH_SHORT).show(); // show success message

            // navigate to main activity
            Intent intent = new Intent(LoginActivity.this, MainActivity.class); // change MainActivity to your actual main activity
            startActivity(intent);
            finish(); // close login activity
        } else {
            // login failed
            Toast.makeText(this, "login failed: invalid username or password", Toast.LENGTH_SHORT).show(); // show error message
        }
    }

    // method to show reset password dialog
    private void showResetPasswordDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this); // create alert dialog builder
        builder.setTitle("Reset Password"); // set dialog title

        // create an input field
        final EditText input = new EditText(this); // input field for email
        input.setHint("Enter your email"); // set hint for input field
        builder.setView(input); // set view of the dialog

        // set positive button for dialog
        builder.setPositiveButton("Submit", (dialog, which) -> {
            String email = input.getText().toString().trim(); // get email input

            if (email.isEmpty()) {
                Toast.makeText(LoginActivity.this, "please enter your email", Toast.LENGTH_SHORT).show(); // show error
            } else {
                // Implement your password reset logic here
                // e.g., send a reset link to the email, update database, etc.
                Toast.makeText(LoginActivity.this, "Reset password link sent to " + email, Toast.LENGTH_SHORT).show(); // show success
            }
        });

        // set negative button for dialog
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel()); // cancel dialog on negative button click

        // show the dialog
        builder.show(); // display the dialog
    }
}
