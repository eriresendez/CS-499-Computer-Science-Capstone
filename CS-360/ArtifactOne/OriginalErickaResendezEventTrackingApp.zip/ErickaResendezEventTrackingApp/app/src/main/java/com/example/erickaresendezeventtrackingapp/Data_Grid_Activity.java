package com.example.erickaresendezeventtrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.database.Cursor;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class Data_Grid_Activity extends AppCompatActivity {
    private DatabaseHandler dbHandler;
    private GridLayout gridEvents;
    private FloatingActionButton addEventButton;
    private List<Event> eventList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_grid);
        dbHandler = new DatabaseHandler(this);

        gridEvents = findViewById(R.id.gridEvents);
        addEventButton = findViewById(R.id.floatingActionButton);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.mainLayout), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        addEventButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Data_Grid_Activity.this, Adding_Data.class);
                startActivity(intent);
            }
        });

        loadEventData(); // Load initial data into the grid
    }

    private void loadEventData() {
        eventList.clear(); // Clear existing data
        Cursor cursor = dbHandler.getAllItems();
        while (cursor.moveToNext()) {
            String name = cursor.getString(cursor.getColumnIndex("item_name"));
            String date = ""; // Add date logic if applicable
            String description = ""; // Add description logic if applicable
            eventList.add(new Event(name, date, description));
        }
        cursor.close(); // Close cursor
        updateGrid();
    }

    private void updateGrid() {
        gridEvents.removeAllViews(); // Clear the grid
        for (int i = 0; i < eventList.size(); i++) {
            Event event = eventList.get(i);

            TextView eventName = new TextView(this);
            eventName.setText(event.getName());
            eventName.setLayoutParams(new GridLayout.LayoutParams());

            TextView eventDate = new TextView(this);
            eventDate.setText(event.getDate());
            eventDate.setLayoutParams(new GridLayout.LayoutParams());

            TextView eventDescription = new TextView(this);
            eventDescription.setText(event.getDescription());
            eventDescription.setLayoutParams(new GridLayout.LayoutParams());

            Button deleteButton = new Button(this);
            deleteButton.setText("Delete");
            deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    deleteEvent(event.getName()); // Delete by name
                }
            });

            gridEvents.addView(eventName);
            gridEvents.addView(eventDate);
            gridEvents.addView(eventDescription);
            gridEvents.addView(deleteButton);
        }
    }

    private void deleteEvent(String itemName) {
        if (dbHandler.deleteItem(itemName)) {
            Toast.makeText(this, "Event deleted.", Toast.LENGTH_SHORT).show();
            loadEventData(); // Reload the grid after deletion
        } else {
            Toast.makeText(this, "Error deleting event.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        dbHandler.close(); // Close database handler
        super.onDestroy();
    }
}
