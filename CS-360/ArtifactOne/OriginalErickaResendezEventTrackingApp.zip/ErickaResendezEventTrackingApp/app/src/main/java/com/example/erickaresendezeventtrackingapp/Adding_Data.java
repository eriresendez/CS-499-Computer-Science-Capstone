package com.example.erickaresendezeventtrackingapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class Adding_Data extends AppCompatActivity {
    private DatabaseHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adding_data);
        dbHandler = new DatabaseHandler(this);

        EditText eventName = findViewById(R.id.editEventName);
        EditText eventDate = findViewById(R.id.editEventDate);
        EditText eventDescription = findViewById(R.id.editEventDescription);
        Button saveEventButton = findViewById(R.id.buttonSaveEvent);

        saveEventButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = eventName.getText().toString();
                String date = eventDate.getText().toString();
                String description = eventDescription.getText().toString();

                // Logic for saving event details
                boolean success = dbHandler.addItem(name, 1); // Example quantity
                if (success) {
                    Toast.makeText(Adding_Data.this, "Event saved!", Toast.LENGTH_SHORT).show();
                    eventName.setText("");
                    eventDate.setText("");
                    eventDescription.setText("");
                } else {
                    Toast.makeText(Adding_Data.this, "Error saving event.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
