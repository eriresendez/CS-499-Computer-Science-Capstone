package com.example.erickaresendezeventtrackingapp;

import android.os.Bundle; // bundle import
import androidx.appcompat.app.AppCompatActivity; // appcompat activity import

public class CreateAccountActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account); // set the layout for the create account screen
    }
}
